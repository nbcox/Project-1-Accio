# Project-1-Accio

Nick Cox, 55648298

For my project, my first issue was getting the skeleton code setup so that it accepted command line argumnets. Luckily that was a simple fix in the main() function for the server and client. Next I ran into the issue of sending a file over TCP. I saw how the message was sent and echoed in the skeleton code, and figured I would go off of that. Using Git was fairly easy, and besides a couple hiccups during setup, I had no issues pushing commits to my private repository.

I used some prior knowledge of C++ and the skeleton code plus lecture videos to help with this project. 
